a = int(input('enter amount '))
b = int(input('enter amount '))
c = int(input('enter amount '))

if a>b and a>c:          # if a is greater from a and c 
     print('a is greater no.')
elif b>a and b>c:   # if b is greater than a and c
     print('b is greater no')
else:
     print('c is greater no')
     
##nested if else / if inside if
if a>b:
     if a>c:
          print('a is greater')
     else:
          print('b is greater')
else:
     if b>c:
          print('b is greater')
     else:
          print('c is greater ')
