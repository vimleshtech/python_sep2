print('text1')
print('text2',end='\t')
print('text3')


a = input('enter data :')
b = input('enter data :')
print(type(a))
print(type(b))

c =a+b
print(c)

a=int(a)  # convert to int
b =int(b)

c = a+b
print(c)




###




