a = int(input('enter hindi marks'))
b = int(input('enter history marks'))
c = int(input('enter maths marks'))
d = int(input('enter eglish marks'))
e = int(input('enter science marks'))
avg = ((a+b+c+d+e)/5)
print ('average marks are:',avg)

if avg<40:
     print('fail')
elif avg>=40 and avg<=49:
     print('third division')
elif avg>=50 and avg<=59:
     print('second division')
else:
     print('first division')

        
            
