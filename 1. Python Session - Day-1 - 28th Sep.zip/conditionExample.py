amt = int(input('enter amount '))

tax =0
#if condition 
if amt>100:
     tax = amt*.10 # calculate tax

#get total
amt = amt+tax
print('total amount :', amt)

amt = int(input('enter amount '))
#if else condition
tax =0
if amt>100:
       tax = amt*.10 # calculate tax
else:
       tax = amt*.05 # calculate tax

     

#get total
amt = amt+tax
print('total amount :', amt)
     

          
