i =1
while i<10:
     print(i)
     i =i+1

     

#print in reverse order
i =10
while i>0:
     print(i)
     i =i-1
     

#print all odd numebrs between 1 to 30
i =1
while i<30:
     print(i)
     i = i+2
     
