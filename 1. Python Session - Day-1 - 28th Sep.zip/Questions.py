salary=int(input('enter your salary'))

if salary>5000 and salary<=10000:
     hra=salary*.10
     da=salary*.05
     
elif salary>10000 and salary<=15000:
     hra=salary*.15
     da=salary*.08
else:
     print('other salary')
     
     
income= salary+hra+da
print('gross income is',income)

