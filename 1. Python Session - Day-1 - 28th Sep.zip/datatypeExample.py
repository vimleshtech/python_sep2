#int
a =11
print(a)
print(type(a))


#float
f =444.33
print(f)
print(type(f))

#bool
b =True
print(b)
print(type(b))

#str
d ='abcd'
print(d)
print(type(d))

#str
d ="abcd"
print(d)
print(type(d))

#list
l = [111,333,4,555,'shss',True]
print(l)
print(type(l))

#tuple
t =(11,222,33,444)
print(t)
print(type(t))


#dict
d ={1:'one','a':'alpha','b':'beta'}
print(d)
print(type(d))

#set
s ={'dove','lux','dove'}
print(s)
print(type(s))










