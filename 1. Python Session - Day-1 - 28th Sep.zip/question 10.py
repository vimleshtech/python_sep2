x=int(input ('eneter the units used'))
y=50     #fixed meter charges
if x<=100:
      bill = x*.40+y      
elif x<=300:
      bill= 100*.40+(x-100)*.50+y      
else:
      bill=100*.40+200*.50+(x-300)*.60+y      

print('your bill is', bill)
