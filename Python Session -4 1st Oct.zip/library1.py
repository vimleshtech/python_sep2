def add():   # def is keyword which define/declare the function , and add is name of function 
     print('hello')
     
#-no argument with return
def getData():
     a = int( input('enter data :'))
     b = int( input('enter data :'))

     return a,b

#-argument with no return
def addNum(a,b):
     print(a+b)
     
#-argument with return 
def subNum(x,y):
     return x-y

