import library1

library1.add()
library1.addNum(1,2)
