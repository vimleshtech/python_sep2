for i in range(1,10):
     if i % 3 ==0:
          break
     print(i)




#continue 
for i in range(1,10):
     if i % 3 ==0:
          continue
     print(i)


##dict example
data = {1:'one',2:'two',3:'three','a':'alpha'}

print(type(data))
#access dict value
print(data[2])
print(data['a'])

##add new element in dict
data['b'] ='beta'
print(data)


data[2] ='delta'
print(data)




     

