#Anonymous functions /default

#global variable
dd =111

def add(a,b,c=0,d=0): #here c,d are default/optional argument
     m = a+b+c+d #here m is local variable which can be access within function
     print(a+b+c+d)

#dynamic argument
def addNum(*ar):  # * : all arguments(multiple argument)
     print(type(ar))
     print(ar)
     s =0  #here is local variable
     
     for a in ar:
          s =s+a
     print(s)
     
     
     

#call
add(11,2)
add(11,2,4)
add(11,2,44,5)

addNum(1111,2,2,3,4,4,4,5,5)
addNum(1111,2,2,3,4,4,4,5,5,4,3,3,3,34,4,4,5)



     
