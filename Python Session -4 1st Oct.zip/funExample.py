#-no argument no return
def add():   # def is keyword which define/declare the function , and add is name of function 
     print('hello')
     
#-no argument with return
def getData():
     a = int( input('enter data :'))
     b = int( input('enter data :'))

     return a,b

#-argument with no return
def addNum(a,b):
     print(a+b)
     
#-argument with return 
def subNum(x,y):
     return x-y


##call to function
add()

x,y = getData()
print(x,y)

a,b = getData()
print(a+b)

#call to function with argument 
addNum(11,2223)
addNum(11,200)

a,b=getData()
addNum(a,b)

##
a = subNum(13,232)
print(a)


