sid  = int(input('enter sid :'))
name  = input('enter name :')
hs  = int(input('enter hindi :'))
es  = int(input('enter eng. :'))
cs  = int(input('enter comp. :'))

total = hs+es+cs
avg = total/3
print(total)
print('average ',avg)

if avg>=80:
     print('A')
elif avg>=60 : #and avg<80
     print('B')
elif avg>=40:
     print('C')
else:
     print('D')


     


     


