f =open(r'C:\Users\vkumar15\Desktop\Weekend\Python Session - Day2.txt','r')

print(len(f.readlines()))
