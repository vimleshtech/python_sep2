#find greater no. from three input
a = int(input('enter num :'))
b = int(input('enter num :'))
c = int(input('enter num :'))

if a>b and a>c:
     print('a is greater no')
elif b>a and b>c:
     print('b is greater no')
else:
     print('c is greater no')


#nested loop : loop inside loop
if a>b:
     if a>c:
          print('a is greater')
     else:
          print('c is greater ')
else:
     if b>c:
          print('b is greater')
     else:
          print('c is greater ')



          


