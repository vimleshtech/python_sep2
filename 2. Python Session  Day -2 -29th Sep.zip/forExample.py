#for example
for i in range(1,10): # from 1 to 9 , default incrementer is 1 ((1,10,1)
     print(i)


print('----')
#print in reverse order
for d in range(10,0,-1):
     print(d)
     
     

