n = int(input('enter num :'))

if n % 2 ==0:
     print(n,' is Even number')
else:
     print(n,' is odd number')
     
