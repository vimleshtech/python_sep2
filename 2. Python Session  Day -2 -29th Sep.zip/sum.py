#sum and average of first n even no
a=input('enter the no:')
a = int(a)

s =0
for i in range(1,a+1):

     if i %2 ==0:
          s = s+i



          
    
print(s)
print(s/a)

     

     
