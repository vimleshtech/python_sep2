#table of no
a=input('enter the no:')
a=int(a)
i=1

for i in range(1,11):
     c=a*i
     
     print(c)
     i+1
     

     
     
     
     
     
