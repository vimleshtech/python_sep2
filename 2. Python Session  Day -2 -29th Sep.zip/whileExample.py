##### while loop
i =1 #init

while i<10: # condition 
     #print(i)       #print and change the line
     print(i,end=',')  # end = don't change the line , print in same line
     
     i =i+1  # incrementer


print('-----')
#print in reverse order
i =10 # init 
while i>0: # condition 
     print(i)
     i =i-1   # decrementer

#print all odd numbers between 1 to 30
i =1
while i<=30:
     print(i)
     i =i+2


#wap to get sum of all even and odd numbers between 1 to 100
se = 0
so = 0
i =1
while i<=100:
     if i%2 ==0:
          se = se+i
     else:
          so = so+i
     i =i+1
     
print('sum of all even no. :',se)
print('sum of all odd no. :',so)


##wap to print table of given no
t = int(input('enter no. :'))
i =1
while i<=10:
     print(t,'*',i,'=',i*t)

     i =i+1

     

     



          



          



     
     
     
     
     
     
