import tweepy
from tweepy import OAuthHandler 
from textblob import TextBlob

ck="Jm6WDXZuiwlwUnT9mFbPdSpcg"
cs="Wp4Gbf74R6MZWjXvj0ifKrCobwWbchhn53Mv8L7VMLbIUi6Wnd"
at="919434545924935681-wFjVVTbs0pmyB2VwSoj4VwGb7tBYCyr"
ats ="RaPfxU0rSMjkS3MSI9N0ztXu4I2iLMecXg79OerNHw4Ly"

au = OAuthHandler(ck, cs)
au.set_access_token(at, ats)
ob = tweepy.API(au) #login 

users =["Narendra Modi","Rahul Gandhi","Donald Trump"]

for u in users:
        
    out = ob.search(q=u,count=5)
    for o in out:
        print(o.text)


