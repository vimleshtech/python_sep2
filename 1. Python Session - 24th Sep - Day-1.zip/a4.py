a=2
square=a*a
print(square)

a=3
cube=a**3
print(cube)

c=input('number')
b=int(c)**3
print(b)
