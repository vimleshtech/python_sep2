a=input('roll number')
b=input('name')
ms=input('marks ms')
es=input('marks ms')
sss=input('marks sss')
hs=input('marks hs')
cs=input('marks cs')

print(a)
print(b)

#print(type(hs))

#type casting / convert from one data type to another data type

total = int(ms) + int(es) + int(sss) + int(hs) + int(cs)
print(total)

avg = total/5
print(avg)
