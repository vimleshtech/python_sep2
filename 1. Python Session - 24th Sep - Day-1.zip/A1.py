a=input('roll number')
c=input('name')
d=input('phone number')
ms=input('marks ms')
es=input('marks es')
hs=input('marks hs')
cs=input('marks cs')
sss=input('marks sss')

print(a)
print(c)
print(d)
#print(type(hs))

#type casting / convert from one data type to another data type
total = int(ms) + int(es) + int(hs) + int(cs) + int(sss)
print(total)

avg = total /5
print(avg)
