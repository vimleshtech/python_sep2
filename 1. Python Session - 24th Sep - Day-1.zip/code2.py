a = input('enter data :')
print('you have entered :',a)
