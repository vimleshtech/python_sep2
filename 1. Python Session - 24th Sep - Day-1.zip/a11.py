a=10
square=int(a)**2
print(square)

b=5
cube=int(b)**3
print('----------')
print(cube)

a=input('roll number')
b=input('name')
c=input('marks')
d=input('phone number')
print('----------')
print(a)
print('----------')
print(b)
print('----------')
print(c)
print('----------')
print(d)



a=input('roll number')
b=input('name')
ms=input('ms')
ss=input('ss')
es=input('es')
cs=input('cs')
hs=input('hs')

print(a)
print(b)

Total = int(ms) + int(ss) + int(es) + int(cs) + int(hs)
print(Total)

avg = Total /5
print(avg)
