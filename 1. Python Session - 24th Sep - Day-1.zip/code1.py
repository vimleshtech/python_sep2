print('hello , this is my first python code',end='\t')
print(111)


a =1
print(type(a))
print(a)


a =1.33444
print(type(a))

a ='fhhfgf'
print(type(a))


a ="sjhjhf"
print(type(a))


a =True
print(type(a))




a =[1,2,34]
print(type(a))



a =(121,2,34)
print(type(a))


a ={'a':'alpha','b':'beta'}
print(type(a))


a ={'dove','lux','dove'}
print(type(a))









