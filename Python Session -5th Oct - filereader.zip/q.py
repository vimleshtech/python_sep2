a ="abcdXYX123 abcD"

all_text = ''
for d in a:
    if ord(d)>=97 and ord(d)<123:
        all_text += d.upper()
    else:
        all_text +=d.lower()

print all_text

        
    
