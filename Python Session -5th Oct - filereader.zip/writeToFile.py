#write data to file
a = open(r'C:\Users\techvision\Desktop\test.txt','a') #create new file if file is not exist


for i in range(1,4):
    d = input('enter data :')
    
    a.write(d)
    a.write('\n')

a.close()





