#here first "r" will ignore the unicode or repalce the  '\' to '\\'
f = open(r'C:\Users\techvision\Desktop\emp.txt','r')

#print(f)
#print  (f.read())  # read all content

#print (f.readline())  # read one line
#print (f.readline())

#print(f.readlines())   # read all content and convert to list

data = f.readlines()
#get no. of rows count
rc = len(data)
print(rc)

for d in data:
    #print(d)
    col = d.split(',')
    print(col[0],col[2])
    


f.close()





