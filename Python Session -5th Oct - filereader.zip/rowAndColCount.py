f = open(r'C:\Users\techvision\Desktop\test.txt','r')

data =f.readlines()
l =len(data)
print ('now of rows ',l)

#get word count
wc = 0

#get particular word count
pwc = 0

for d in data:
    col = d.split(' ')
    wc += len(col)
    for c in col:
        if c =='is':
            pwc +=1


print('word count ',wc)
print('is count ',pwc)

