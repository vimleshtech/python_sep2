def swapWithExtra():
     a=111
     b=444
     c =a
     a=b
     b=c
     print('a =',a)
     print('b =',b)
     

#call to function 
swapWithExtra()
