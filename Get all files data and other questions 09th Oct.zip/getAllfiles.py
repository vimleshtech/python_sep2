import os
path = r'C:\Users\vkumar15\Desktop\Weekend'
d = os.listdir(path)

#print(d)

wf = open(r'C:\Users\vkumar15\Desktop\out.txt','w') #w - write mode
for f in d:
     #print(f)
     #read all .txt file
     if f.endswith('.txt'):
          #print(f)

          #read content from all text file
          data = open(path+'\\'+f,'r')  #r - read mode
          wf.write(data.read())
          #print(path+'\\'+f)


wf.close()

          
          
          
     


