def getASCII(data):
     for c in data:
          print(ord(c))



d = input('enter string :')

getASCII(d)

