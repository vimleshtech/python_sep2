import mysql.connector

#establish the connnection from python to database server
con = mysql.connector.connect(host='localhost',user='root',password='root',database='hrms')
cr =con.cursor() #create variable/object of cursor() - execute/fire the sql command
cr.execute('select * from emp')
res = cr.fetchall()

#print(res)
for r in res:
     print(r)
     



