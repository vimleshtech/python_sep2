from m1 import calc

class dcalc(calc):

     def mul(a,b,c):
          print(b*c)



     
