'''
from m2 import dcalc

o = dcalc()

o.mul(11,3)
o.add(33,3)
'''
from m3 import tax

o =tax()
o.get_tax(4344444)
