#- no argument no return
def wel():
     print('....this code contains following functions: \n i. wel \n ii. getdata \n iii. add(a,b) \n iv. sub(a,b) ')

#- no argument with return
def getdata():
     a = int(input('enter data :'))
     b = int(input('enter data :'))
     return a,b

#- argument with no return
def add(a,b):
     c =a+b
     print(c)
     
#- argument with return
def sub(a,b):
     c =a-b
     return c

#-with default argument
def addNum(a,b,c=0,d=0):
     x =a+b+c+d
     print(x)
     
#-dynamic argument
def mul(*a): #argument type is tuple
     print(a)
     x = 1
     for n in a:
          x *= n

     print(x)
     
     
#-recurrsive
def fact(n):

     if n ==1:
          return n
     else:
          return n*fact(n-1)
     
