class calc:

     def add(s,a,b):
          print(a+b)

     def sub(a,b,c):
          print(b-c)



