class employee:

     def newemp(s):
          #print('new emp ',s)
          s.eid = input('enter eid :')
          s.ename = input('enter name:')
          s.sal = int(input('enter sal :'))
          

     def __init__(self,country):
          
          self.eid =0
          if country=='india':
               self.ename ='guest user'
          else:
               self.ename ='new user'
               
          self.sal =0
          self.msal=0
          print(self,' object is created ')
          
          
     def compute(a):
          #print('compute ',a)
          #print(type(a.sal))          
          a.msal =a.sal *12
          #print(a.msal)
          
          
          

     def __del__(s):
          print(s,' is deleted ')
          
     def show(x):
          #print('show ',s)
          print('employee details...')
          print('id is : ',x.eid)
          print('name  is : ',x.ename)
          print('sal is : ',x.sal)
          print('monthly sal is : ',x.msal)
          
#
#emmployee o =new employee()
o = employee('uk')
#print(o)
o.show()

o.newemp()
#o.__init__('test')

o.compute()
o.show()

del o

#o.show() #error

#o1 = employee()
#o1.compute()
#o1.show()



          
