from m2 import dcalc
#from m1 import calc

class tax(dcalc):

     def get_tax(a,sal):
          if sal<300000:
               print('no tax')
          else:
               print('tax applicable')

          
