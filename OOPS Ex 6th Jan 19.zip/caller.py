import moduleEx as a

a.add(11,2)
x,y = a.getdata()

print(x-y)


