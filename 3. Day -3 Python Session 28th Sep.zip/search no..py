count = 0

l=[1,2,2,3,3,3,4,10,10,10,12,13]
a=int(input('enter no  :'))

for d in l:
     if d==a:         
          count=count+1


print('count of ',a,' is ',count)

