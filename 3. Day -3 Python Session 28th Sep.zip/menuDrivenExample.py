data =[] #declare empty list

while True:

     op = input('press 1 for add 2 for show 3 for remove 4 for exit ')

     if op =='1':
          d = input('enter data :')
          data.append(d)

     elif op=='2':
          print(data)
     elif op =='3':
          r = input('enter data to remove :')
          if r in data:
               data.remove(r)
          else:
               print('given value is not found ,so cannot be removed')
     elif op=='4':
          break
     else:
          print('you have entere invalid choice , please retry ')
          
          
     
