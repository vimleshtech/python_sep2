sales = [111,22,233,4444]

#print sales values
print(sales)

#read value by index
print(sales[0]) # 1st element

#slicer
print(sales[0:3]) # return 0 to 2 
print(sales[:3]) # return 0 to 2
print(sales[-1]) #   read from right side
print(sales[-2]) #2nd last 
print(sales[0:-1])

#print in reverse order
print(sales[::-1])  #from last to first element 

#max
print(max(sales))

#min
print(min(sales))

#sum
print(sum(sales))

#len
print(len(sales))

#sort : default in acending order 
sales.sort()
print(sales)

#in decdinding
print(sales[::-1])


##take input from user
d = int(input('enter data :'))
sales.append(d)

print(sales)


##pop : remove last element
sales.pop()
print(sales)




























