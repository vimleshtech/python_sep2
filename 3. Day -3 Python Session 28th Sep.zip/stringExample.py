name = input('enter name :')

ns =name.upper()
print(ns)

ns =name.lower()
print(ns)



ns =name.title()
print(ns)


ns =name.replace('a','xy')
print(ns)

l = len(name)
print(l)


d = list(name)
print(d)

##get count of words from sentnce
d = name.split(' ')
print(d)
l = len(d)
print('count of word ',l)









     
