import mysql.connector

#connect to mysql server database
con = mysql.connector.connect(host='localhost',user='root',password='root',database='learning')

#create object of cursor which can execute sql statement or command
cr = con.cursor()

def readData():
     #execute sql command
     cr.execute("select * from emp")

     #read data from cr and to list 
     res = cr.fetchall()  #select

     #print data 
     #print(res)
     for r in res:
          print(r[0],r[1])
     
def writeData():
     #execute sql command
     #cr.execute("insert into emp(eid,name) values(100,'jatin')")
     i = input('enter id :')
     n = input('enter name :')

     s ="insert into emp(eid,name) values("+i+",'"+n+"')"
     print(s)
     cr.execute(s)
     #save data   / commit transaction to  save 
     con.commit()  #insert, update , delete 
          

readData()
writeData()
readData()

con.close()
