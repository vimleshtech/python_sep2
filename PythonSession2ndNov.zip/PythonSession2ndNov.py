#read data from .txt
#: there is inbuilt module which provide open function

#read data from .csv
#: need to install pandas

#read data from excel
#: need to install xlrd
import xlrd
import pandas as pd

path=r'C:\Users\vkumar15\Desktop\Raw Data.xlsx'

workbook = xlrd.open_workbook(path) 
sheet = workbook .sheet_by_index(0)
#no of rows 
print(sheet.nrows)

#no of cols
print(sheet.ncols)

#get/read data from given index(row,col)
print(sheet.cell_value(9,0))

col1=[]
col2=[]

#read data / interate by loop index
for  r in range(9,sheet.nrows):
     #for  c in range(0,sheet.ncols):
     #print(sheet.cell_value(r,1),sheet.cell_value(r,3))
     col1.append(sheet.cell_value(r,1))
     col2.append(sheet.cell_value(r,3))
          
df =pd.DataFrame(data={'client':col1,'issue':col2})

print(df.columns)
print(col1)
print(col2)
print(df['client'])
print(df['issue'])


          
##write data frame to csv
df.to_csv(r'C:\Users\vkumar15\Desktop\out.csv')




          


     




