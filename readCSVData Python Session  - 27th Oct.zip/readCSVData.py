import pandas as pd

df = pd.read_csv(r'C:\Users\vkumar15\Desktop\Weekend\red-green-anova-example.csv')
print(df)


print(df.columns)
print(df.groupby('color').size())

x =df.loc[df['color']  =='green' ]

print( x.loc[x['block']  =='w' ]  )
