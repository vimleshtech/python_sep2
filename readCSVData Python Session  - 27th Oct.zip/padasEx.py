import pandas  as pd 

#create blank dataframe 
df = pd.DataFrame()
print(df)

name=['raman','jatin','ayush','monika']
gender=['male','male','male','female']
salary=[11111,22222,34455,33421]
eid=[101,201,301,401]

df = pd.DataFrame(data={'eid':eid,'empname':name,'gender':gender,'sal':salary})

#print all data
print(df)

#shape : return row and col dimenssion 
print(df.shape)

#head  : return top given rows
print(df.head(2))

#tail : return buttom given rows 
print(df.tail(3))  

#columns : return list of columns 
print(df.columns)

#group by : summary the data 
print(df.groupby('gender').size())
print(df.groupby('gender').max())
print(df.groupby('gender').min())
print(df.groupby('gender').sum())

print(df.groupby('gender').sum()['sal'])


#order by : sorting 
print( df.sort_values('gender',ascending=True))
print( df.sort_values('gender',ascending=False))

print( df.sort_values('sal',ascending=False))

#show stats 
print(df.describe())




