a =[111,22,34,4,555]


print(max(a))
print(min(a))
print(sum(a))
print(len(a))


