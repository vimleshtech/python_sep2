sales = 3334444
tax = sales*.10

print(sales)
print(tax)
