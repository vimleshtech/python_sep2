sid  = input('enter id :')
sname  = input('enter name :')
hs =  int(input('enter mark in hs :'))
es  = int(input('enter mark in es :'))
cs  = int(input('enter mark in cs :'))


total = hs+es+cs
avg = total/3

print('sid : ',sid)
print('name: ',sname)
print('total score: ',total)
print('average score : ',avg)
if avg>=80:
     print('A')
elif avg>=60:
     print('B')
elif avg>=40:
     print('C')
else:
     print('D')
     
