'''
i = 1
while i<5:
     print(i)
     i=i+1

i=5
while i>0:
     print(i)
     i = i-1

i = 5
while i<10:
     print(i)
     i = i+1
i = 1
while i<=10:
     print('output is ', i)
     i=i+2

'''


i=2
while i<=10:
     print ('even number ',i)
     i=i+2


i=1
while i<=10:
     if i% 2 ==0:
          print ('even number ',i)
     i=i+1



se=0
so =0
i =1
while i<=10:
     if i%2 ==0:
          se = se+i
     else:
          so=so+i
     i=i+1
print ('sum of all even ',se)
print ('sum of all odd ',so)



'''
#WAP to print the sum and average of first n odd numbers

a=int(input('enter number :'))
so=0
i=a+1
while i<a:
      i%2 ==0
      so = so+i
      print('sum of all odd ',so) 

'''
