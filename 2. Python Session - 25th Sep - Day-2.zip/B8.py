sal=int(input('enter salary :'))

if sal>=5000 and sal<=10000:
     print('salary is : ', sal)
     hra=sal*.10
     da=sal*.05
     print('hra is :', hra)
     print('da is :', da)
#printhra=sal*.10

     
elif sal>=10001 and sal<=15000:
     hra=sal*.15
     da=sal*.08
     print('salary is : ', sal)
     print('hra is : ', hra)
     print('da is : ', da)
      
