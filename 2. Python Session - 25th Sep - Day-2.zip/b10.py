unit=int(input('enter units :'))

if unit<=100:
     rate=unit*.4

elif unit>100 and unit<=300:
     rate=unit*.5

else:
     unit>300
     rate=unit*.6

print('rate is :', rate)
amount = rate + 50
print('amount due is :', amount)
     
