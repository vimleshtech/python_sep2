n = int(input('enter sale amount  :'))
tax = 0

#if condition 
if n>1000:
     tax = n*.10


total_sal= n+tax
print('total amount :',total_sal)

####################
## if else
if n>1000:
     
     tax = n*.10
else:
     tax = n*.05
     
total_sal= n+tax
print('total amount :',total_sal)

     
     
