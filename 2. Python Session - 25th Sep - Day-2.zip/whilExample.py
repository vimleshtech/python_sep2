i = 1 #init
while i<20: #condition
     print(i)
     i = i+1  #increment


#print in reverse order
i =10
while i>0:
     print(i)
     i =i-1 #decreement


#print all odd numbers between 1 to 30
i =1  #init
while i<=30: #condition 
     print('ouput is ',i)
     i =i+2 #increment 
     
#wap to print sum of all even no. and odd numbers between 1 to 100
se =0
so = 0
i =1 
while i<=100:
     if i%2 ==0:
          se = se+i
     else:
          so = so+i
     i=i+1
     

print('sum of all even ',se)
print('sum of all odd ',so)


