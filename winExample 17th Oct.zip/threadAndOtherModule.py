import time
import threading

'''
thread : is proces (task)
multiple threading : multiple task /process

'''
l = time.localtime()
print(l)
print(l.tm_year)
print(l.tm_mon)
print(l.tm_mday)

def process1():
     for i in range(1,5):
          print(i)
          time.sleep(1)


def process2():
     for i in range(11,15):
          print(i)
          time.sleep(1)

     

#process1()
#process2()

p1 = threading.Thread(target=process1,name='a')
p2 = threading.Thread(target=process2,name='b')
time.sleep(2)

p1.start()
p2.start()











          

