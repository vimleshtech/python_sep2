'''
GUI : graphical user interface
module name
     import tkinter 
'''
from tkinter import *
import mysql.connector

t = Tk()

t.geometry("500x300")
              
l1  = Label(text='enter name ')
l1.pack()

t1 = Entry()
t1.pack()

l2 = Label()
l2.pack()

def getData():
     d = t1.get()
     print('you have entered :',d)
     l2.configure(text=d)
     con = mysql.connector.connect(host='localhost',user='root',password='root',database='dbhrms')
     cur =con.cursor()

     cur.execute("insert into tbl_user(name) values('"+d+"')")

     con.commit()
     con.close()
     
     
     
b1 = Button(text='Click Me',command=getData)
b1.pack()


t.mainloop()



