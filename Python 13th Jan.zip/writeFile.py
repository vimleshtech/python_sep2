f=open(r'C:\Users\KR872923\Desktop\file new1.txt',"w")
def employee():
    for i in range (0,5):
        gender=input("enter the gender:")
        eid=input("enter the id:")
        sallery=input("enter the sallery:")
        d=input("enter the Name:")

        f.write(eid+'\t')
        f.write(sallery+'\t')
        f.write(gender+'\t')
        f.write(d+'\t')
        #f.write(',')
        f.write('\n')
    f.close()

    
    print("Data is saved")
    
employee()
