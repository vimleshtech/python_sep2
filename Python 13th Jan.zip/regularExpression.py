import re

s = input('enter data :')

o = re.match('(.*) is (.*)',s)

if o:
    print('matched ... ')
    print(o.groups())
    print(o.group(0))  #print all 
    print(o.group(1)) #first group  / BEFORE IS 
    print(o.group(2)) #2nd GROUP  / AFTER IS                        
    
else:
    print('not match')

###check email id
e = input('etner email id :')

o = re.match('(.*)@gmail.com',e)
if o:
    print('gmail account')
else:
    print('other account ')


##search
e = input('etner email id :')
o = re.search('^a',e)
print(o)

if o:
    print('start with a ')
else:
    print('not start with a')
    



    

    





    



    

    

