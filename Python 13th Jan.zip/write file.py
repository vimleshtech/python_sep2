g=open(r'C:\Users\KR872923\Desktop\file new1.txt',"r")

data=g.readlines()

s = 0

for r in data:
    c = r.split('\t')
    #print(c)
    s = s+int( c[1])

print(s)

    

'''
for i in range(0,5):
    el=list[i].split(",")
    print(el[0])
    
    
    for j in range(0,len(el)):
        #print(el[j])
        print(el[0])
    
   # print(el)
   '''

   

    
