while True:
    
    
    try:
        num1 = int(input("Enter 1st number: "))
        num2 = int(input("Enter 2nd number: "))
        if num2<0:
            e =ZeroDivisionError('divisor cannot be less than 0')
            raise e 
        c = num1/num2
        print(c)
        break
    
    except:
        print("invalid input, pls try again")
