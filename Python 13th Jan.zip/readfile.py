f=open(r'C:\Users\KR872923\Desktop\file.txt',"r")
a=0
file=(f.read())
print(file)
data=file.split(" ")
for i in data:
    if i=="to":
        a=a+1
print(a)


"""
f=open(r'C:\Users\KR872923\Desktop\file new1.txt',"w")
for i in range (1,5):
    d=input("enter the data")
    f.write(d+'\n')
    f.close()
    print("Data is saved")
    
"""    
    
