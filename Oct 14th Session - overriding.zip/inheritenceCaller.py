from clac import calc2

class compute(calc2):
     def tax(s,sal):
          if sal<3000000:
               print('no tax')
          else:
               print('taxable income')



class test(calc2):
     def hi(s):
          print('hi function ')

#
class a:
     def t1(s):
          print('t1')
          
class b:
     def t2(s):
          print('t2')


class c(a,b):
     def t3(s):
          print('t3')

                             
#create object of child class

o = compute()
o.add(11,2)
o.sub(433,44)
o.tax(43333)

t = test()
t.hi()
t.add(11,22)
#t.tax(3334)













