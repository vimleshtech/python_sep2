a =11  # global 
class test:


     def f1(s):
          x =11 #local variable , within function 
          s.y = 100  #global , within class
          print(x)
     def f2(a):
          #print(x) # cannot be accessed
          print(a.y)
          
          





print(a)
t =test()
t.f1()
t.f2()

