'''
class
object
self

encapsulation  : wrapping of data member and function in one unit i.e. encapsulation
               : every class is by default encapsulated
               
               
abstraction    : to exposure the essential features of class,methods and hide the implementation of method i.e. abstraction

constructor    : is function which will invoke or call automatically
                 when object will create
               : __init__()  is default function
               
deconstructor  : is function which invoke or call automatically when object will be deleted
               : __del__()  is default function
               
inheritence    : to extend one class feature in another class
               There are following types of inheritence:
                    i. single level
                                   A -> B
                    ii. multi level
                                   A -> B  -> C.... -> D
                    iii. tree
                              A -> B , C , D -> X, Y

                    iv. hybrid
                              A -> B -> C...
                              x -> y,z
                    v. multiple
                              A,B,C ... -> D

                              
Overriding:
          multiple function have same name i.e. called overriding
          
          
               

'''

class test:
     def hi(self):
          print('tesst class - hi function')

     def __init__(s):
               print('object is created',s)
     def __del__(s):
          print('object is deleted ')
          

#create object
o = test()
o.hi()


###
del  o
#o.hi() #will not work 




          


          

          
