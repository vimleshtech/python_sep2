class calc2:
     def add(s,a,b):
          c =a+b
          print(c)

     def sub(s,a,b):
          c =a-b
          print(c)





     
     
