try:          
     n = int(input('enter no :'))
     d = int(input('enter no :'))
     o = n/d
     print(o)
except ValueError as e:
          print('type convertion error ',e)    

except ZeroDivisionError as z:
     print('maths error ',z)
except:
     print('other error ')
finally:       #finally is optional block which will execute always either exception will occur or not
     print('end of block')

     
     
