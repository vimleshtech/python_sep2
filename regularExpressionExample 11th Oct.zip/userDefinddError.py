#user defind error
try:          
     n = int(input('enter no :'))
     d = int(input('enter no :'))
     
     if d<0:
          ex = ValueError('divisor cannot be less than 1')
          raise ex
     
     o = n/d
     
     print(o)
     
except ValueError as e:
          print('type convertion error ',e)
except:
     print('error')
     
