import re #regular expression

'''
pattern:

[a-z]  : from a to z
[A-Z]  : from A to Z
[0-9]  : fro 0 to 9
/d     : digit   0-9
/D     : non digit
/w     : char
/W     : non char
()      : group
.       : any char/digit/special char
*     : any no. of times
^     : start with
$      : end with


'''

data = input('enter data ')
o = re.match('(.*) is (.*)',data)
if o:
     print('is present')
else:
     print('is no present')


#gmail validate
email = input('enter gmail id :')
a = re.match('(.*)@gmail.com',data)


if a:
     print('match')
else:
     print('not match')


     

     






     


     

     



