import time

t = time.localtime()
print(t)

print(t.tm_year)
print(t.tm_mon)


for i in range(1,10):
    print(i)
    time.sleep(2)  #delay 
    
