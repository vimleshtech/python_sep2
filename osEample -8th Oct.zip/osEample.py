import os
import shutil

path = os.listdir(r'C:\Users\Tech Vision\Desktop')
#print(path)

for f in path:
    #print(f)
    #read all .txt file
    if f.endswith('.txt'):
        #print(f) #from file and to file 
        shutil.copy(r'C:\Users\Tech Vision\Desktop\\'+f,r'C:\Users\Tech Vision\Desktop\out')
        
    

