from Accounts import BankAccount as b

class SavingAccount(b):

    def documents(s):
        s.addproof = input('enter add prrof :')
        s.idproof = input('etner pan no. :')
        s.bal = input('enter amt for deposit :')

    def balanceSheet(s):
        print('Pan no :',s.idproof)
        print('Total bal :',s.bal)


class test(b):
    def ab(s):
        print('test')
        

class CurrentAccount:
    def ca(s):
        print('ca')

#multiple 
class CreditAccount(CurrentAccount,b):
    def cc(s):
        print('cc')

        




#create object
o = SavingAccount()
o.newAccount()
o.documents()
o.show()
o.balanceSheet()
