def add(a,b):
    print(a+b)

def add(a,b,c):
    print(a+b+c)


add(4,2112,4)


