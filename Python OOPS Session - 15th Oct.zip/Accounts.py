class BankAccount:


    def show(s):
        print('Account id :',s.id)
        print('Account name :',s.acname)


    def newAccount(s):
        s.id = input('enter account id :')
        s.acname = input('etner account name :')    
