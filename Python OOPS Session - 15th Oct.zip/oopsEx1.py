#declartion of class
class calc: 
    #methods/function s
    def add(s,a,b):  #we have to receive at least one argument in every function which takes the ref of current object
        c =a+b
        print(c)
        print(s)

    def sub(ad,a,b):
        c =a-b
        print(c)
        print(ad)
    def input2(self):
        self.i = int(input('enter data : '))
        self.name = input('enter name :')
        self.hs = int(input('enter score in hindi :'))
        self.es = int (input('enter score in eng :'))        
        self.cs = int (input('enter score in comp. :'))
        self.ms = int (input('enter score in maths. :'))

    def __del__(ad):
        print(ad, ' is deleted ')
        
    def compute(s):
        s.total = s.hs+s.es+s.cs+s.ms
        s.avg = s.total /4
    def show(a):
        print(a.i)
        print(a.name)
        print(a.total)
        print(a.avg)

    def __init__(self):
        print('object is created ')
        self.i = 0
        self.name = ''
        self.hs = 0
        self.es = 0      
        self.cs =0
        self.ms = 0
        self.total=0
        self.avg =0
        
        





#create object
s=calc() #invoke to consturctor __init__()
s.show()
print(s)   # is address of object

s.add(22,3) #s object reference will pass on first argument
s.sub(44,5)

s.input2()
s.compute()
s.show()

del s  #invoke to deconstrutor __del__()


#s.add(11,2)


